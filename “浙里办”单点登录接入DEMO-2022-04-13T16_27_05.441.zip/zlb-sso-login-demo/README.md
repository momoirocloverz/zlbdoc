# 浙里办单点登录demo

## 前端demo

src/main/resources/public/index.html

## 后端demo

src/main/java/com/demo/zlb/sso/login/controller/AuthController.java

启动项目，访问
http://localhost:8080/index.html?ticketId=ticketId
可实现单点登录