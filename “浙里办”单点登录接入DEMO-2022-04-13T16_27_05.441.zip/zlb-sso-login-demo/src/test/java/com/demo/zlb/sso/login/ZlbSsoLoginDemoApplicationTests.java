package com.demo.zlb.sso.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZlbSsoLoginDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
