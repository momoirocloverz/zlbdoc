package com.demo.zlb.sso.login.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * 检测应用是否启动成功
 *
 * @author jie.chen
 * @date 2022-03-30 15:14
 */
@RestController
public class PingController {

    public String ping() {
        return "pong";
    }
}
