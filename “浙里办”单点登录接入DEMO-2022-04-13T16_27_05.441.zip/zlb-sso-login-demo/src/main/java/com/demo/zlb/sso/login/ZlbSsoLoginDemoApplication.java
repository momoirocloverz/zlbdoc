package com.demo.zlb.sso.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZlbSsoLoginDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZlbSsoLoginDemoApplication.class, args);
    }

}
