package com.demo.zlb.sso.login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author jie.chen
 * @date 2022-03-30 19:13
 */
@Controller
public class IndexController {

    @GetMapping("/index")
    public ModelAndView index() {
        return new ModelAndView("index.html");
    }

}
