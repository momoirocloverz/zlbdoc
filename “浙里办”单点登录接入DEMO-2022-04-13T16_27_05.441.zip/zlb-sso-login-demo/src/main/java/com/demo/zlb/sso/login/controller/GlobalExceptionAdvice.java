package com.demo.zlb.sso.login.controller;

import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * @author jie.chen
 * @date 2022-03-30 17:51
 */
@RestControllerAdvice
public class GlobalExceptionAdvice {

    @ExceptionHandler(RuntimeException.class)
    public Map<String, Object> handleRuntimeException(RuntimeException e) {
        JSONObject result = new JSONObject();
        result.put("code", "error");
        result.put("msg", e.getLocalizedMessage());
        return result;
    }

}
